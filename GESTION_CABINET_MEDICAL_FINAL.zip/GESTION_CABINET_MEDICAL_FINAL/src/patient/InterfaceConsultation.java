/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patient;

import gestion_cabinet_medical_final.GESTION_CABINET_MEDICAL_FINAL;
import jade.gui.GuiEvent;
import javafx.collections.FXCollections;
import static javafx.collections.FXCollections.observableList;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.effect.Blend;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Font;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;

/**
 *
 * @author dell
 */
public class InterfaceConsultation extends Stage {

     // Création des éléments de l'interface
        TabPane tabPane = new TabPane();
        Tab consultationTab = new Tab("Consultation");
        Tab prescriptionTab = new Tab("Prescription(s)");
        
        AnchorPane consultationContent = new AnchorPane();
        //Listview <>
        GridPane gridPane=new GridPane();
        //Temporaire je recupère la valeur de l'observable List à partir du dépôt central. 
        ObservableList<String> listeConversationPatientMedecin=FXCollections.observableArrayList();
        ListView<String> listViewMessages=new ListView<String>(listeConversationPatientMedecin);

        
        //TextFlow consultationTextFlow = new TextFlow();
        TextArea consultationTextArea = new TextArea();

        Button consultationLeaveButton = new Button("Partir");
        Button consultationSendButton = new Button("Envoyer");
        Label consultationTitleLabel = new Label("*** Consultation en cours ***");

        AnchorPane prescriptionContent = new AnchorPane();
        Label diagnosisLabel = new Label("Diagnostic : ");
        Label prescriptionLabel = new Label("Ordonnance : ");
        TextFlow diagnosisTextFlow = new TextFlow();
        TextFlow prescriptionTextFlow = new TextFlow();
        Button prescriptionLeaveButton = new Button("Partir");

      
    public TextArea getConsultationTextArea() {
        return consultationTextArea;
    }

    public void setConsultationTextArea(TextArea consultationTextArea) {
        this.consultationTextArea = consultationTextArea;
    }
    
        
          public InterfaceConsultation() {
          
           // Configuration des éléments
       /* consultationTextFlow.setLayoutX(14);
        consultationTextFlow.setLayoutY(32);
        consultationTextFlow.setPrefHeight(226);
        consultationTextFlow.setPrefWidth(358);
        consultationTextFlow.setStyle("-fx-border-color: purple; -fx-background-color: white;");
*/
        gridPane.setLayoutX(14);
        gridPane.setLayoutY(32);
        gridPane.setPrefHeight(226);
        gridPane.setPrefWidth(358);
        gridPane.setStyle("-fx-border-color: purple; -fx-background-color: white;");

        
        
        consultationTextArea.setLayoutX(14);
        consultationTextArea.setLayoutY(270);
        consultationTextArea.setPrefHeight(106);
        consultationTextArea.setPrefWidth(267);
        consultationTextArea.setStyle("-fx-border-color: green;");

        consultationLeaveButton.setId("leave");
        consultationLeaveButton.setDefaultButton(true);
        consultationLeaveButton.setLayoutX(300);
        consultationLeaveButton.setLayoutY(332);
        consultationLeaveButton.setMnemonicParsing(false);
        consultationLeaveButton.setPrefHeight(31);
        consultationLeaveButton.setPrefWidth(70);
        consultationLeaveButton.setStyle("-fx-border-color: black; -fx-background-color: purple;");
        consultationLeaveButton.setTextFill(javafx.scene.paint.Color.WHITE);
        consultationLeaveButton.setFont(new Font(13));
        consultationLeaveButton.setEffect(new Blend());

        consultationSendButton.setId("send");
        consultationSendButton.setDefaultButton(true);
        consultationSendButton.setLayoutX(301);
        consultationSendButton.setLayoutY(281);
        consultationSendButton.setMnemonicParsing(false);
        consultationSendButton.setPrefHeight(31);
        consultationSendButton.setPrefWidth(70);
        consultationSendButton.setStyle("-fx-border-color: green; -fx-background-color: green;");
        consultationSendButton.setTextFill(javafx.scene.paint.Color.WHITE);
        consultationSendButton.setFont(new Font(13));
        consultationSendButton.setEffect(new Blend());

        consultationTitleLabel.setLayoutX(73);
        consultationTitleLabel.setLayoutY(7);
        consultationTitleLabel.setFont(new Font("Consolas Bold Italic", 15));

        diagnosisLabel.setLayoutX(27);
        diagnosisLabel.setLayoutY(26);
        diagnosisLabel.setFont(new Font("Consolas Bold", 12));

        prescriptionLabel.setLayoutX(27);
        prescriptionLabel.setLayoutY(169);
        prescriptionLabel.setFont(new Font("Consolas Bold", 12));

        diagnosisTextFlow.setLayoutX(113);
        diagnosisTextFlow.setLayoutY(26);
        diagnosisTextFlow.setPrefHeight(112);
        diagnosisTextFlow.setPrefWidth(260);
        diagnosisTextFlow.setStyle("-fx-border-color: purple;");

        prescriptionTextFlow.setLayoutX(113);
        prescriptionTextFlow.setLayoutY(169);
        prescriptionTextFlow.setPrefHeight(160);
        prescriptionTextFlow.setPrefWidth(260);
        prescriptionTextFlow.setStyle("-fx-border-color: purple;");

        prescriptionLeaveButton.setId("leave");
        prescriptionLeaveButton.setDefaultButton(true);
        prescriptionLeaveButton.setLayoutX(158);
        prescriptionLeaveButton.setLayoutY(345);
        prescriptionLeaveButton.setMnemonicParsing(false);
        prescriptionLeaveButton.setPrefHeight(31);
        prescriptionLeaveButton.setPrefWidth(70);
        prescriptionLeaveButton.setStyle("-fx-border-color: black; -fx-background-color: purple;");
        prescriptionLeaveButton.setTextFill(javafx.scene.paint.Color.WHITE);
        prescriptionLeaveButton.setFont(new Font(13));
        prescriptionLeaveButton.setEffect(new Blend());

        // Ajout des éléments aux conteneurs
        consultationContent.getChildren().addAll(gridPane, consultationTextArea, consultationLeaveButton,
                consultationSendButton, consultationTitleLabel);
        consultationTab.setContent(consultationContent);

        prescriptionContent.getChildren().addAll(diagnosisLabel, prescriptionLabel, diagnosisTextFlow,
                prescriptionTextFlow, prescriptionLeaveButton);
        prescriptionTab.setContent(prescriptionContent);

        tabPane.getTabs().addAll(consultationTab, prescriptionTab);

        gridPane.add(listViewMessages, 0, 0);        
        
        
        // Création de la scène et affichage de la fenêtre
        AnchorPane root = new AnchorPane(tabPane);
        root.setPadding(new Insets(10));
        Scene scene = new Scene(root, 387, 420);
        setScene(scene);
        setTitle("Patient");
        
        
        
   
        
        }
          
         
    
}
