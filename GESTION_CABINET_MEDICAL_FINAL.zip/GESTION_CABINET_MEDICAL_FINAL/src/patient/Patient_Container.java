/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patient;


import gestion_cabinet_medical_final.GESTION_CABINET_MEDICAL_FINAL;
import jade.core.AID;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.gui.GuiEvent;
import jade.lang.acl.ACLMessage;
import jade.util.ExtendedProperties;
import jade.util.leap.Properties;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.ControllerException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.effect.Blend;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;


public class Patient_Container extends Application {
    
    public Patient_Agent patientAgent;
    
    
    inscriptionPatientInterface inscriptionInterface = new inscriptionPatientInterface();
    InterfaceConsultation interfaceConsultation=inscriptionInterface.getInterfaceConsultation();
          
  
    boolean verrou_infoFormulaire=false;
    
    
    public Patient_Agent getPatientAgent() {
        return patientAgent;
    }

    public void setPatientAgent(Patient_Agent patientAgent) {
        this.patientAgent = patientAgent;
    }
    
public static void main (String[] args){
    launch(Patient_Container.class); // POur lancer l'interface Graphique , par Appel de la méthode Start definie plus bas. 
    
    
}

public void startContainer(){
try{
    Runtime runtime= Runtime.instance();
    Profile profile=new ProfileImpl(false);
    profile.setParameter(Profile.MAIN_HOST,"localhost");
    AgentContainer Patient_Container=runtime.createAgentContainer(profile);
    AgentController Patient_agentController=
            Patient_Container.createNewAgent("Patient_Agent","patient.Patient_Agent"
                                            ,new Object []{this});
    Patient_agentController.start();
    }
catch (ControllerException e){
     e.printStackTrace();
        
}
}


public void start (Stage primaryStage ) throws Exception {
        startContainer();
        
        inscriptionInterface.show();
        // gestion des évènements
        
        //gestion du click sur le boutton
          
       interfaceConsultation.consultationSendButton.setOnAction(new EventHandler <ActionEvent>(){
        @Override 
        public void handle(ActionEvent event){
        
            String message=interfaceConsultation.getConsultationTextArea().getText();
          
            System.out.println("je suis le patient et j'ai ecris:"+message);
            ACLMessage aclMessage=new ACLMessage(ACLMessage.REQUEST);
            aclMessage.setContent(message);
            aclMessage.addReceiver(new AID("Medecin_Agent",AID.ISLOCALNAME));
            patientAgent.send(aclMessage);
           // format_message(message);
            
            // je recupère ce que la patient a ecrit et je l'envois 
            //interfaceConsultation.zoneCentrale.ListConversationPatientMedecin.add(message);
            interfaceConsultation.getConsultationTextArea().clear();
            interfaceConsultation.listeConversationPatientMedecin.add(message);
           
            
           
        } } );
       
       
       
       // Le gestion du sexe
   // inscriptionInterface
     inscriptionInterface.toggleGroup.selectedToggleProperty().addListener((observable, oldValue, newValue) -> {
            if (newValue != null) {
                RadioButton selectedRadioButton = (RadioButton) newValue;
                patientAgent.setSexe(selectedRadioButton.getText());
            }
        });
     
     
    //gestion du button enregister
    
    inscriptionInterface.Benregistrer.setOnAction(new EventHandler <ActionEvent>(){
        @Override 
        public void handle(ActionEvent event){
            
            if(inscriptionInterface.TFnom.getText()==null){
             inscriptionInterface.Linformation.setText("Veuillez Entrer vos informations");
       
         }
            else{
                
            //recuperation formulaire 
            patientAgent.setNom(inscriptionInterface.TFnom.getText());
            patientAgent.setPrenom(inscriptionInterface.TFprenom.getText());
            patientAgent.setAge(inscriptionInterface.TFage.getText());
            patientAgent.setAdresse(inscriptionInterface.TFadresse.getText());
            patientAgent.setTelephone(inscriptionInterface.TFtelephone.getText());
            
             System.out.println("nom: "+patientAgent.getNom()+" prenom: "+patientAgent.getPrenom()+" age: "+patientAgent.getAge()+" sexe: "+patientAgent.getSexe()
                                +"adresse: "+patientAgent.getAdresse()+"telephone: "+patientAgent.getTelephone());
            
             if(verrou_infoFormulaire==false){
             inscriptionInterface.Linformation.setText("Informations Enregistreés");
             verrou_infoFormulaire=true;
             }
             else{
              inscriptionInterface.Linformation.setText("Nouvelles Informations Enregistreés");
           }
            
            }}
    
    });
    
    
    //gestion du button consulter
    
    inscriptionInterface.Bconsulter.setOnAction(new EventHandler <ActionEvent>(){
        @Override 
        public void handle(ActionEvent event){
            
            
         if(verrou_infoFormulaire==false){
             inscriptionInterface.Linformation.setText("Veuillez Entrer vos informations");
       
         }
         else{
            inscriptionInterface.close();
            interfaceConsultation.show();
           
        }}
    
    });
    
    //gestion du button Partir 
    interfaceConsultation.consultationLeaveButton.setOnAction(new EventHandler <ActionEvent>(){
        @Override 
        public void handle(ActionEvent event){
            interfaceConsultation.close();
            inscriptionInterface.show();
        }
        });
    
    
}

    
    public void viewMessage(GuiEvent guiEvent){
        if(guiEvent.getType()==1){
            String message=guiEvent.getParameter(0).toString();
            System.out.println(message);
            interfaceConsultation.listeConversationPatientMedecin.add(message);
        }}

     
    }     


