/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package patient;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;

/**
 *
 * @author dell
 */
public class inscriptionPatientInterface extends Stage {

     InterfaceConsultation interfaceConsultation=new InterfaceConsultation();
     //Definition des objets
        AnchorPane anchorPane = new AnchorPane();
        Label Ltitre=new Label ();
        Pane Pinscription = new Pane ();
            
            Label Lnom=new Label ();
            TextField TFnom=new TextField();
            Label Lprenom=new Label ();
            TextField TFprenom=new TextField();
            Label Lage=new Label ();
            TextField TFage=new TextField();
            Label Lsexe=new Label ();
            RadioButton RBfeminin=new RadioButton();
            RadioButton RBmasculin=new RadioButton();
            ToggleGroup toggleGroup=new ToggleGroup();
            
            Label Ladresse=new Label ();
            TextField TFadresse=new TextField();
            Label Ltelephone=new Label ();
            TextField TFtelephone=new TextField();
            Button Benregistrer=new Button("Enregistrer");
            Button Bconsulter=new Button("Consulter");
            Label Linformation=new Label();
     
      
    public InterfaceConsultation getInterfaceConsultation() {
        return interfaceConsultation;
    }
           
    public inscriptionPatientInterface (){
    
            RBfeminin.setToggleGroup(toggleGroup);
            RBmasculin.setToggleGroup(toggleGroup);
            
            
     //Ajout des éléments aux conteneurs.      
            Pinscription.getChildren().addAll(Lnom,TFnom,Lprenom,TFprenom,Lage,
                                      TFage,Lsexe,RBfeminin,RBmasculin,
                                      Ladresse,TFadresse,Ltelephone,
                                    TFtelephone,Benregistrer,Bconsulter,Linformation);
            anchorPane.getChildren().addAll(Ltitre,Pinscription);
            
     // Definition des caractéristiques des objets
     
     Ltitre.setLayoutX(150);
     Ltitre.setLayoutY(10);
     Ltitre.setText("Mes Informations");
     Ltitre.setAlignment(Pos.CENTER);
     Ltitre.setFont(new Font("Consolas Bold Italic",15));

     Pinscription.setFocusTraversable(true);
     Pinscription.setLayoutY(38);
     Pinscription.setPrefWidth(386);
     Pinscription.setPrefHeight(400);
     Pinscription.setStyle("-fx-background-color: snow;");
     
     
    Lnom.setLayoutX(37);
    Lnom.setLayoutY(38);
    Lnom.setPrefWidth(59);
    Lnom.setPrefHeight(26);
    Lnom.setText("Nom(s)");
    Lnom.setAlignment(Pos.CENTER);
    Lnom.setFont(Font.font("Consolas", 12));

    TFnom.setLayoutX(107);
    TFnom.setLayoutY(38);
    TFnom.setPrefWidth(240);
    TFnom.setPrefHeight(25);
    TFnom.setPromptText("Entrez votre nom");

    Lprenom.setLayoutX(37);
    Lprenom.setLayoutY(78);
    Lprenom.setPrefWidth(61);
    Lprenom.setPrefHeight(26);
    Lprenom.setText("Prénom(s)");
    Lprenom.setTextAlignment(TextAlignment.CENTER);
    Lprenom.setFont(Font.font("Consolas", 12));

    TFprenom.setLayoutX(107);
    TFprenom.setLayoutY(80);
    TFprenom.setPrefWidth(240);
    TFprenom.setPrefHeight(25);
    TFprenom.setPromptText("Entrez votre prénom");

    Lage.setLayoutX(37);
    Lage.setLayoutY(119);
    Lage.setPrefWidth(59);
    Lage.setPrefHeight(26);
    Lage.setText("Âge");
    Lage.setTextAlignment(TextAlignment.CENTER);
    Lage.setFont(Font.font("Consolas", 12));

    TFage.setLayoutX(107);
    TFage.setLayoutY(119);
    TFage.setPrefWidth(75);
    TFage.setPrefHeight(25);
    TFage.setPromptText("Âge");

    Lsexe.setLayoutX(37);
    Lsexe.setLayoutY(156);
    Lsexe.setPrefWidth(59);
    Lsexe.setPrefHeight(26);
    Lsexe.setText("Sexe");
    Lsexe.setTextAlignment(TextAlignment.CENTER);
    Lsexe.setFont(Font.font("Consolas", 12));


    RBfeminin.setLayoutX(108);
    RBfeminin.setLayoutY(157);
    RBfeminin.setPrefWidth(32);
    RBfeminin.setPrefHeight(25);
    RBfeminin.setText("F");

    RBmasculin.setLayoutX(159);
    RBmasculin.setLayoutY(157);
    RBmasculin.setPrefWidth(32);
    RBmasculin.setPrefHeight(25);
    RBmasculin.setText("M");
 

    Ladresse.setLayoutX(37);
    Ladresse.setLayoutY(195);
    Ladresse.setPrefWidth(59);
    Ladresse.setPrefHeight(26);
    Ladresse.setText("Adresse");
    Ladresse.setTextAlignment(TextAlignment.CENTER);
    Ladresse.setFont(Font.font("Consolas", 12));

    TFadresse.setLayoutX(107);
    TFadresse.setLayoutY(195);
    TFadresse.setPrefWidth(240);
    TFadresse.setPrefHeight(25);
    TFadresse.setPromptText("Entrez votre adresse");

    Ltelephone.setLayoutX(36);
    Ltelephone.setLayoutY(235);
    Ltelephone.setPrefWidth(61);
    Ltelephone.setPrefHeight(26);
    Ltelephone.setText("Téléphone");
    Ltelephone.setTextAlignment(TextAlignment.CENTER);
    Ltelephone.setFont(Font.font("Consolas", 12));

    TFtelephone.setLayoutX(107);
    TFtelephone.setLayoutY(235);
    TFtelephone.setPrefWidth(239);
    TFtelephone.setPrefHeight(25);
    TFtelephone.setPromptText("****...");

    Benregistrer.setLayoutX(130);
    Benregistrer.setLayoutY(270);
    Benregistrer.setPrefWidth(147);
    Benregistrer.setPrefHeight(31);
    Benregistrer.setDefaultButton(true);
    Benregistrer.setStyle("-fx-border-color: green; -fx-background-color: green; -fx-border-radius: 50;");
    Benregistrer.setTextFill(Color.WHITE);
    Benregistrer.setTextAlignment(TextAlignment.CENTER);
    Benregistrer.setFont(Font.font(13));
    
    Bconsulter.setLayoutX(130);
    Bconsulter.setLayoutY(320);
    Bconsulter.setPrefWidth(147);
    Bconsulter.setPrefHeight(31);
    Bconsulter.setDefaultButton(true);
    Bconsulter.setStyle("-fx-border-color: green; -fx-background-color: green; -fx-border-radius: 50;");
    Bconsulter.setTextFill(Color.WHITE);
    Bconsulter.setTextAlignment(TextAlignment.CENTER);
    Bconsulter.setFont(Font.font(13));
    
    Linformation.setLayoutX(100);
    Linformation.setLayoutY(370);
    Linformation.setPrefWidth(300);
    Linformation.setPrefHeight(26);
    Linformation.setText(".........");
    Linformation.setTextAlignment(TextAlignment.CENTER);
    Linformation.setFont(Font.font("Consolas", 12));

    
   

    // Création de la scène et affichage de la fenêtre
        AnchorPane root = new AnchorPane(anchorPane);
        root.setPadding(new Insets(10));
        Scene scene = new Scene(root,420,450);
        setTitle("Patient");
        setScene(scene);
        
        
    
    //gestion des évènements 
    
    
    }
}

    

