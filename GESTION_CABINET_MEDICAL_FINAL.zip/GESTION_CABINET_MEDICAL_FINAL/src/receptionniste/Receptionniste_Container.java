/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package receptionniste;


import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.gui.GuiEvent;
import jade.util.ExtendedProperties;
import jade.util.leap.Properties;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.ControllerException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class Receptionniste_Container extends Application {
    
    /**************Declaration des variables et constantes*************/
     private Receptionniste_Agent receptionnisteAgent;

    public Receptionniste_Agent getReceptionnisteAgent() {
        return receptionnisteAgent;
    }

    public void setReceptionnisteAgent(Receptionniste_Agent receptionnisteAgent) {
        this.receptionnisteAgent = receptionnisteAgent;
    }
    TableView<User> tableView1;
    TableView<User> tableView2;
    ObservableList<User> user1;
    ObservableList<User> user2;
    
    
    /********************Fin declaration Variable et Constantes***************/
    
    
    
public static void main (String[] args){
    launch(Receptionniste_Container.class); }




public void start (Stage primaryStage ) throws Exception {
        startContainer();
        
        /*****************************Interface Receptionniste***************/
         // Creation des colonnes du tableau  
        
        TableColumn<User,Integer> numeroCol1 = new TableColumn<User, Integer>("Numéro");
        TableColumn<User,String> nomCol1 = new TableColumn<User, String>("Nom");
        TableColumn<User,Integer> ageCol1 = new TableColumn<User, Integer>("Age");
        TableColumn<User,String> sexeCol1 = new TableColumn<User, String>("Sexe");
        
        numeroCol1.setCellValueFactory(new PropertyValueFactory<>("numero"));
        nomCol1.setCellValueFactory(new PropertyValueFactory<>("nom"));
        ageCol1.setCellValueFactory(new PropertyValueFactory<>("age"));
        sexeCol1.setCellValueFactory(new PropertyValueFactory<>("sexe"));
        
        TableColumn<User,Integer> numeroCol2 = new TableColumn<User, Integer>("Numéro");
        TableColumn<User,String> nomCol2 = new TableColumn<User, String>("Nom");
        TableColumn<User,Integer> ageCol2 = new TableColumn<User, Integer>("Age");
        TableColumn<User,String> sexeCol2 = new TableColumn<User, String>("Sexe");
        TableColumn<User,String> status = new TableColumn<User,String>("Statut");
        
        numeroCol2.setCellValueFactory(new PropertyValueFactory<>("numero"));
        nomCol2.setCellValueFactory(new PropertyValueFactory<>("nom"));
        ageCol2.setCellValueFactory(new PropertyValueFactory<>("age"));
        sexeCol2.setCellValueFactory(new PropertyValueFactory<>("sexe"));
        status.setCellValueFactory(new PropertyValueFactory<>("statut"));
        
         // creation du tableau avec tableView
         tableView1 = new TableView<>();
        boolean addAll;
        addAll = tableView1.getColumns().addAll(numeroCol1,nomCol1,ageCol1,sexeCol1);
        tableView1.setPrefWidth(400);
        
        tableView2 = new TableView<>();
        boolean addAll1;
        addAll = tableView2.getColumns().addAll(numeroCol2,nomCol2,ageCol2,sexeCol2,status);
        tableView2.setPrefWidth(400);
        
        //Demonstration 
        user1 = FXCollections.observableArrayList(
            new User(1,"Lea",20,"F"),
            new User(1,"Line",21,"F"),
            new User(1,"Nassair",22,"M"),
            new User(1,"Lea",20,"F"),
            new User(1,"Line",21,"F"),
            new User(1,"Nassair",22,"M"),
            new User(1,"Lea",20,"F"),
            new User(1,"Line",21,"F"),
            new User(1,"Nassair",22,"M"),
            new User(1,"Nassair",22,"M"),
            new User(1,"Lea",20,"F"),
            new User(1,"Line",21,"F"),
            new User(1,"Nassair",22,"M")
        ); 
        //Ajout des donnees dans le tableau
        tableView1.setItems(user1);
        
        //label pour le nom  des tableaux
        Label label1 = new Label("DEMANDE DE CONSULTATION");
        
        Label label2 = new Label("ETAT DE CONSULTATION");
      
        user2 = FXCollections.observableArrayList();
        //creation et action du bouton
        Button buttonAccepte = new Button("Accepté");    
        
        //page utilisateur
        VBox vBox = new VBox();
        vBox.setSpacing(20);
        vBox.getChildren().addAll(
                new HBox(label1),
                new HBox(tableView1),
                new HBox(buttonAccepte),
                new HBox(label2),
                new HBox(tableView2)
                
        );
        
        //Creation de la scene 
        Scene scene = new Scene(vBox, 400, 600);
        
        //affichage 
        primaryStage.setScene(scene);
        primaryStage.setTitle("RECEPTION");
        primaryStage.show();
        
  /***************************Gestion des évènements*****************/
        
buttonAccepte.setOnAction(new EventHandler <ActionEvent>(){
        @Override 
        public void handle(ActionEvent event){
        /*test guiEvent***********/
            String livre="test envoie donnée";
            //observableList.add(livre);
            GuiEvent guiEvent=new GuiEvent (this,1);
            guiEvent.addParameter(livre);
            receptionnisteAgent.onGuiEvent(guiEvent);
            
        //ajout dans le 2ieme tableau
             User selectedUser = tableView1.getSelectionModel().getSelectedItem();
            if(selectedUser != null){
                tableView1.getItems().remove(selectedUser);
                selectedUser.setStatus("En attente");
                user2.add(selectedUser);
                tableView2.setItems(user2);
            }
            
        }
        });



/***********************************Fin Gestion Evènements****************/

        
}




public void startContainer(){
try{
    Runtime runtime= Runtime.instance();
    Profile profile=new ProfileImpl(false);
    profile.setParameter(Profile.MAIN_HOST,"localhost");
    AgentContainer Receptionniste_Container=runtime.createAgentContainer(profile);
    AgentController Receptionniste_agentController=
            Receptionniste_Container.createNewAgent("Receptionniste_Agent","receptionniste.Receptionniste_Agent"
                                            ,new Object []{this});

    Receptionniste_agentController.start();
    }
catch (ControllerException e){
     e.printStackTrace();
        
}
}



public class User{
        private int numero;
        private String nom;
        private int age;
        private String sexe;
        private String statut;

        
        public User(int numero, String nom, int age, String sexe){
            this.numero = numero;
            this.nom = nom;
            this.age = age;
            this.sexe = sexe;
            this.statut = "En attente";
        }
       
        public int getNumero() {
            return numero;
        }

        public void setNumero(int numero) {
            this.numero = numero;
        }

        public String getNom() {
            return nom;
        }

        public void setNom(String nom) {
            this.nom = nom;
        }

        public int getAge() {
            return age;
        }

        public void setAge(int age) {
            this.age = age;
        }

        public String getSexe() {
            return sexe;
        }

        public void setSexe(String sexe) {
            this.sexe = sexe;
        }

        public String getStatus() {
            return statut;
        }

        public void setStatus(String status) {
            this.statut = statut;
        }
        
    }
    


}
