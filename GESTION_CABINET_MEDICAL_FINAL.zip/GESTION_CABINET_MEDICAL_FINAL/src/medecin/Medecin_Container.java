/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medecin;

import gestion_cabinet_medical_final.GESTION_CABINET_MEDICAL_FINAL;
import jade.core.AID;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.gui.GuiEvent;
import jade.lang.acl.ACLMessage;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.ControllerException;
import java.io.IOException;
import javafx.application.Application;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.Button;
import javafx.scene.control.TabPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TextArea;
import javafx.scene.control.ListView;
import javafx.scene.control.Label;
import javafx.scene.text.TextFlow;
import javafx.scene.image.ImageView;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TableCell;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;
import medecin.Medecin_Agent;

public class Medecin_Container extends Application {
        
   
    String fichierLecture = "C:\\Users\\dell\\Desktop\\semestre 2 4gi\\Systeme Expert et systeme multi agent\\SMA\\GESTION_CABINET_MEDICAL_FINAL\\Health Bot avec les fichiers\\send_by_doctor_expert.txt";
    String fichierEcriture = "C:\\Users\\dell\\Desktop\\semestre 2 4gi\\Systeme Expert et systeme multi agent\\SMA\\GESTION_CABINET_MEDICAL_FINAL\\Health Bot avec les fichiers\\send_by_patient.txt";
    
    MedecinInterface medecin_interface=new MedecinInterface();
   
    private  Medecin_Agent medecin_agent;
    public Medecin_Agent getMedecin_agent() {
        return medecin_agent;
    }
    public  void setMedecin_agent(Medecin_Agent medecin_agent) {
        this.medecin_agent = medecin_agent;
    }
    
    
     
    
public static void main (String[] args){
    launch(Medecin_Container.class); // POur lancer l'interface Graphique , par Appel de la méthode Start definie plus bas. 
    
}




public void startContainer(){
try{
    jade.core.Runtime runtime= jade.core.Runtime.instance();
    Profile profile=new ProfileImpl(false);
    profile.setParameter(Profile.MAIN_HOST,"localhost");
    AgentContainer Medecin_Container=runtime.createAgentContainer(profile);
   AgentController Medecin_agentController=
            Medecin_Container.createNewAgent("Medecin_Agent","medecin.Medecin_Agent",new Object []{this});

    Medecin_agentController.start();
    }
catch (ControllerException e){
     e.printStackTrace();
        
}
}

@Override
public void start(Stage primaryStage) throws Exception {
   
    startContainer();
    
     medecin_interface.show();
    
    medecin_interface.Benvoyer.setOnAction(new EventHandler <ActionEvent>(){
        @Override 
        public void handle(ActionEvent event){
        
            
            String message=medecin_interface.getZoneSaisie().getText();
            System.out.println("je suis le medecin et j'ai ecris:"+message);
            ACLMessage aclMessage=new ACLMessage(ACLMessage.REQUEST);
            aclMessage.setContent(message);
            aclMessage.addReceiver(new AID("Patient_Agent",AID.ISLOCALNAME));
           // patientAgent.send("sending test");
            medecin_agent.send(aclMessage);
            
            // je recupère ce que la patient a ecrit et je l'envois 
            medecin_interface.listeConversationPatientMedecin.add(message);
            medecin_interface.getZoneSaisie().clear();
           
            
            
        
        }});
      
    
}

public void viewMessage(GuiEvent guiEvent){
    
            if(guiEvent.getType()==1){
            String message=guiEvent.getParameter(0).toString();
            medecin_interface.listeConversationPatientMedecin.add(message);
            System.out.println(message);
        }

}

   
    public String format_message(String message)
    {
       String  messageFormated=("{\"pb\":\""+message+"\"}");
       //JSONObject jsonObject = new JSONObject(jsonString);
       
       return messageFormated ;
    
       //  {"pb":"j'ai mal à la tête"}
    }
}
    




