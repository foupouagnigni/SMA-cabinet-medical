/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package medecin;


import gestion_cabinet_medical_final.GESTION_CABINET_MEDICAL_FINAL;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.StrokeType;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;

/**
 *
 * @author dell
 */
public class MedecinInterface extends Stage{
    
    ObservableList<User> user1;
    ObservableList<String> listeConversationPatientMedecin=FXCollections.observableArrayList();
    ListView<String> listViewMessages=new ListView<String>(listeConversationPatientMedecin);

    
    AnchorPane anchorPane = new AnchorPane();
        
        Text TTitre=new Text();
        Text TConsultation=new Text();
        
       
         
            TableView<User> tableView = new TableView<>();
            TableColumn<User, Integer> TC1 = new TableColumn<>("Numero");
            TableColumn<User, String> TC2 = new TableColumn<>("Nom");
            TableColumn<User, Integer> TC3 = new TableColumn<>("Age");
            TableColumn<User, String> TC4 = new TableColumn<>("Sexe");
            TableColumn TC5 = new TableColumn<>("Action");
            
        TabPane SecondPane=new TabPane();
            Tab Tdiscussion=new Tab();
                Pane Pdiscussion=new Pane();
                    GridPane zoneReponse=new GridPane();
                    TextArea zoneSaisie=new TextArea();

    public TextArea getZoneSaisie() {
        return zoneSaisie;
    }

    public void setZoneSaisie(TextArea zoneSaisie) {
        this.zoneSaisie = zoneSaisie;
    }
                    Button Benvoyer=new Button();
                    
            Tab TDiagPresc=new Tab();
                Pane PDiagPresc=new Pane();
                    TextArea zoneSaisieDiag=new TextArea();
                    TextArea zoneSaisiePresc=new TextArea();
                    Label LDiagnostic=new Label();
                    Label LPrescription=new Label();
                    Button BenvoyerDiagPresc=new Button();
                    
            Tab TInfoPatient=new Tab();
                Pane PInfoPatient=new Pane();
                    Label LInfoPatientnom=new Label();
                    Label LInfoPatientprenom=new Label();
                    Label LInfoPatientsexe=new Label();
                    Label LInfoPatientIdConsult=new Label();
            Tab TInfoConsult=new Tab();
                Pane PInfoConsult =new Pane();
                    Label LInfoConsultNomPrenom = new Label();
                    TextFlow TFInfoConsultNomPrenom =new TextFlow();
                    Label LInfoConsultAge = new Label();
                    TextFlow TFInfoConsultAge =new TextFlow();
                    Label LInfoConsultSexe = new Label();
                    TextFlow TFInfoConsultSexe =new TextFlow();
                    Label LInfoConsultDate= new Label();
                    TextFlow TFInfoConsultDate =new TextFlow();
                    Label LInfoConsultPrescription= new Label();
                    TextFlow TFInfoConsultPrescription =new TextFlow();
                    Label LInfoConsultDiagnostic= new Label();
                    TextFlow TFInfoConsultDiagnostic =new TextFlow();
                    Label LInfoConsultId = new Label();
                    TextFlow TFInfoConsultId =new TextFlow();
                    Label LInfoConsultRendezVous = new Label();
                    TextFlow TFInfoConsultRendezVous =new TextFlow();
       Button Bterminé=new Button();
        Button BrendezVous=new Button();
    
    
    public MedecinInterface() {
        
        
        user1 = FXCollections.observableArrayList(
            new User(1,"Lea",20,"F"),
            new User(1,"Line",21,"F"),
            new User(1,"Nassair",22,"M"),
            new User(1,"Lea",20,"F"),
            new User(1,"Line",21,"F"),
            new User(1,"Nassair",22,"M"),
            new User(1,"Lea",20,"F"),
            new User(1,"Line",21,"F"),
            new User(1,"Nassair",22,"M"),
            new User(1,"Nassair",22,"M"),
            new User(1,"Lea",20,"F"),
            new User(1,"Line",21,"F"),
            new User(1,"Nassair",22,"M")
        ); 
        
        //ajout aux conteneurs
        anchorPane.getChildren().addAll(TTitre,TConsultation,tableView,SecondPane,Bterminé,BrendezVous); 
        tableView.getColumns().addAll(TC1, TC2, TC3, TC4, TC5);
        
        SecondPane.getTabs().addAll(Tdiscussion,TDiagPresc,TInfoPatient,TInfoConsult);
            Tdiscussion.setContent(Pdiscussion);
                Pdiscussion.getChildren().addAll(zoneSaisie,zoneReponse,Benvoyer);
            
                TDiagPresc.setContent(PDiagPresc);
                PDiagPresc.getChildren().addAll(zoneSaisieDiag,zoneSaisiePresc,LDiagnostic,LPrescription,BenvoyerDiagPresc);
            TInfoPatient.setContent(PInfoPatient);
                PInfoPatient.getChildren().addAll(LInfoPatientnom,LInfoPatientprenom,LInfoPatientsexe,LInfoPatientIdConsult);
            TInfoConsult.setContent(PInfoConsult);
                PInfoConsult.getChildren().addAll(LInfoConsultNomPrenom,TFInfoConsultNomPrenom,LInfoConsultAge,
                                                  TFInfoConsultAge,LInfoConsultSexe,TFInfoConsultSexe,LInfoConsultDate
                                                 ,TFInfoConsultDate,LInfoConsultPrescription,TFInfoConsultPrescription,LInfoConsultDiagnostic,TFInfoConsultDiagnostic,LInfoConsultId,TFInfoConsultId,LInfoConsultRendezVous,
                                                  TFInfoConsultRendezVous);
        
    //Definition de Caractéristiques
            TC1.setCellValueFactory(new PropertyValueFactory<>("numero"));
            TC2.setCellValueFactory(new PropertyValueFactory<>("nom"));
            TC3.setCellValueFactory(new PropertyValueFactory<>("age"));
            TC4.setCellValueFactory(new PropertyValueFactory<>("sexe"));
            TC5.setCellFactory(tableColumn -> new ButtonCell(tableView)); 
            tableView.setItems(user1);
        
      
        
       TTitre.setLayoutX(7);
       TTitre.setLayoutY(19);
       TTitre.setStrokeType(StrokeType.OUTSIDE);
       TTitre.setWrappingWidth(600.0);
       TTitre.setTextAlignment(TextAlignment.CENTER);    
       TTitre.setText("Bureau Du Médécin");
      // TTitre.setFill("0d0101eb");
       
       TConsultation.setLayoutX(22);
       TConsultation.setLayoutY(46);
       TConsultation.setWrappingWidth(239.13671875);
       TConsultation.setStrokeType(StrokeType.OUTSIDE);
       TConsultation.setText("Liste Consultations");
       
     
        tableView.setLayoutX(15);
        tableView.setLayoutY(57);
        tableView.setPrefHeight(107);
        tableView.setPrefWidth(571);

       SecondPane.setLayoutX(15);
       SecondPane.setLayoutY(176);
       SecondPane.setPrefHeight(297);
       SecondPane.setPrefWidth(571);
       SecondPane.setStyle("-fx-border-color: black;");
       
       Tdiscussion.setText("Discussion");
        Pdiscussion.setPrefHeight(232);
        Pdiscussion.setPrefWidth(312);
            zoneSaisie.setLayoutX(23);
            zoneSaisie.setLayoutY(156);
            zoneSaisie.setPrefHeight(61);
            zoneSaisie.setPrefWidth(531);
            
            
            zoneReponse.setLayoutX(23);
            zoneReponse.setLayoutY(14);
            zoneReponse.setPrefHeight(122);
            zoneReponse.setPrefWidth(533);
            listViewMessages.setLayoutX(23);
            listViewMessages.setLayoutY(14);
            listViewMessages.setPrefHeight(122);
            listViewMessages.setPrefWidth(533);
            
            Benvoyer.setLayoutX(444);
            Benvoyer.setLayoutY(236);
            Benvoyer.setPrefHeight(25);
            Benvoyer.setPrefWidth(113);
            Benvoyer.setText("Envoyer");
            
       TDiagPresc.setText("DIAGNOSTIC-PRESCRIPTION");
            PDiagPresc.setPrefHeight(232);
            PDiagPresc.setPrefWidth(312);
                LDiagnostic.setLayoutX(53);
                LDiagnostic.setLayoutY(35);
                LDiagnostic.setText("Diagnostic");//
                LPrescription.setLayoutX(321);
                LPrescription.setLayoutY(35);
                LPrescription.setText("Prescription");//
                zoneSaisieDiag.setLayoutX(31);
                zoneSaisieDiag.setLayoutY(70);
                zoneSaisieDiag.setPrefHeight(131);
                zoneSaisieDiag.setPrefWidth(200);//
                zoneSaisiePresc.setLayoutX(309);
                zoneSaisiePresc.setLayoutY(68);
                zoneSaisiePresc.setPrefHeight(135);
                zoneSaisiePresc.setPrefWidth(221);//
                BenvoyerDiagPresc.setLayoutX(242);
                BenvoyerDiagPresc.setLayoutY(201);
                BenvoyerDiagPresc.setText("Envoyer");
       TInfoPatient.setText("INFOS-PATIENTS");
            PInfoPatient.setPrefHeight(232);
            PInfoPatient.setPrefWidth(312);//
                LInfoPatientnom.setLayoutX(24);
                LInfoPatientnom.setLayoutY(26);
                LInfoPatientnom.setText("Nom");
                LInfoPatientprenom.setLayoutX(26);
                LInfoPatientprenom.setLayoutY(64);
                LInfoPatientprenom.setText("Age");
                LInfoPatientsexe.setLayoutX(25);
                LInfoPatientsexe.setLayoutY(97);
                LInfoPatientsexe.setText("Sexe");
                LInfoPatientIdConsult.setLayoutX(24);
                LInfoPatientIdConsult.setLayoutY(196);
                LInfoPatientIdConsult.setPrefHeight(44);
                LInfoPatientIdConsult.setPrefWidth(85);
                LInfoPatientIdConsult.setText("IdConsultation");
            
       TInfoConsult.setText("INFOS-CONSULTATIONS");
            PInfoConsult.setPrefHeight(232);
            PInfoConsult.setPrefWidth(312);//
                LInfoConsultNomPrenom.setLayoutX(24);
                LInfoConsultNomPrenom.setLayoutY(26);
                LInfoConsultNomPrenom.setText("Nom Prenom");
                TFInfoConsultNomPrenom.setLayoutX(100);
                TFInfoConsultNomPrenom.setLayoutY(22);
                TFInfoConsultNomPrenom.setPrefHeight(25);
                TFInfoConsultNomPrenom.setPrefWidth(200);
                TFInfoConsultNomPrenom.setStyle("-fx-border-color: black;");
                LInfoConsultAge.setLayoutX(26);
                LInfoConsultAge.setLayoutY(64);
                LInfoConsultAge.setText("Age");
                TFInfoConsultAge.setLayoutX(71);
                TFInfoConsultAge.setLayoutY(64);
                TFInfoConsultAge.setPrefHeight(25);
                TFInfoConsultAge.setPrefWidth(200);
                TFInfoConsultAge.setStyle("-fx-border-color: black;");
                
                LInfoConsultSexe.setLayoutX(25);
                LInfoConsultSexe.setLayoutY(97);
                LInfoConsultSexe.setText("Sexe");
                TFInfoConsultSexe.setLayoutX(71);
                TFInfoConsultSexe.setLayoutY(93);
                TFInfoConsultSexe.setPrefHeight(25);
                TFInfoConsultSexe.setPrefWidth(200);
                TFInfoConsultSexe.setStyle("-fx-border-color: black;");
                
                LInfoConsultDate.setLayoutX(22);
                LInfoConsultDate.setLayoutY(139);
                LInfoConsultDate.setPrefHeight(44);
                LInfoConsultDate.setPrefWidth(40);
                LInfoConsultDate.setText("Date");
                TFInfoConsultDate.setLayoutX(78);
                TFInfoConsultDate.setLayoutY(149);
                TFInfoConsultDate.setPrefHeight(25);
                TFInfoConsultDate.setPrefWidth(153);
                TFInfoConsultDate.setStyle("-fx-border-color: black;");
                
                
                LInfoConsultDiagnostic.setLayoutX(427);
                LInfoConsultDiagnostic.setLayoutY(18);
                LInfoConsultDiagnostic.setText("Diagnostic");
                TFInfoConsultDiagnostic.setLayoutX(355);
                TFInfoConsultDiagnostic.setLayoutY(43);
                TFInfoConsultDiagnostic.setPrefHeight(99);
                TFInfoConsultDiagnostic.setPrefWidth(200);
                TFInfoConsultDiagnostic.setStyle("-fx-border-color: black;");
                
                LInfoConsultPrescription.setLayoutX(420);
                LInfoConsultPrescription.setLayoutY(144);
                LInfoConsultPrescription.setText("Precription");
                TFInfoConsultPrescription.setLayoutX(351);
                TFInfoConsultPrescription.setLayoutY(172);
                TFInfoConsultPrescription.setPrefHeight(82);
                TFInfoConsultPrescription.setPrefWidth(200);
                TFInfoConsultPrescription.setStyle("-fx-border-color: black;");
                
                LInfoConsultId.setLayoutX(24);
                LInfoConsultId.setLayoutY(196);
                LInfoConsultId.setText("IdConsultation");
                TFInfoConsultId.setLayoutX(119);
                TFInfoConsultId.setLayoutY(192);
                TFInfoConsultId.setPrefHeight(25);
                TFInfoConsultId.setPrefWidth(200);
                TFInfoConsultId.setStyle("-fx-border-color: black;");
                
                LInfoConsultRendezVous.setLayoutX(28);
                LInfoConsultRendezVous.setLayoutY(222);
                LInfoConsultRendezVous.setText("Rendez-Vous");
                TFInfoConsultRendezVous.setLayoutX(119);
                TFInfoConsultRendezVous.setLayoutY(230);
                TFInfoConsultRendezVous.setPrefHeight(25);
                TFInfoConsultRendezVous.setPrefWidth(200);
                TFInfoConsultRendezVous.setStyle("-fx-border-color: black;");
   
    Bterminé.setLayoutX(400);
    Bterminé.setLayoutY(501);
    Bterminé.setText("Terminé");
    BrendezVous.setLayoutX(478);
    BrendezVous.setLayoutY(501);
    BrendezVous.setText("Rendez-Vous");
                
    
    zoneReponse.add(listViewMessages, 0, 0);
    
    
    
    // Création de la scène et affichage de la fenêtre
        AnchorPane root = new AnchorPane(anchorPane);
        root.setPadding(new Insets(10));
        Scene scene = new Scene(root,600,560);
        setTitle("Medecin");
        setScene(scene);
        
}
    
    public static class User {
        private final SimpleIntegerProperty numero;
        private final SimpleStringProperty nom;
        private final SimpleIntegerProperty age;
        private final SimpleStringProperty sexe;

        public User(int numero, String nom, int age, String sexe) {
            this.numero = new SimpleIntegerProperty(numero);
            this.nom = new SimpleStringProperty(nom);
            this.age = new SimpleIntegerProperty(age);
            this.sexe = new SimpleStringProperty(sexe);
        }

        public int getNumero() {
            return numero.get();
        }

        public SimpleIntegerProperty numeroProperty() {
            return numero;
        }

        public void setNumero(int numero) {
            this.numero.set(numero);
        }

        public String getNom() {
            return nom.get();
        }

        public SimpleStringProperty nomProperty() {
            return nom;
        }

        public void setNom(String nom) {
            this.nom.set(nom);
        }

        public int getAge() {
            return age.get();
        }

        public SimpleIntegerProperty ageProperty() {
            return age;
        }

        public void setAge(int age) {
            this.age.set(age);
        }

        public String getSexe() {
            return sexe.get();
        }

        public SimpleStringProperty sexeProperty() {
            return sexe;
        }

        public void setSexe(String sexe) {
            this.sexe.set(sexe);
        }
    }

    private class ButtonCell extends TableCell<User, Boolean> {
        final Button c = new Button("C");
        final Button r = new Button("R");
        final HBox hbox = new HBox(c, r);

        ButtonCell(@SuppressWarnings("rawtypes") final TableView tableView) {
            c.setStyle("-fx-border-radius: 25;");
            c.setOnAction(actionEvent -> {
                int selectedIndex = getTableRow().getIndex();
                User user = (User) tableView.getItems().get(selectedIndex);
                System.out.println(user.getNumero());
            });
        }

        @Override
        protected void updateItem(Boolean t, boolean empty) {
            super.updateItem(t, empty);
            if (!empty) {
                setGraphic(hbox);
            }
        }
    }
    
    
    
}
